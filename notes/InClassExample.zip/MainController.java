
package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class MainController {

    @FXML
    private Button addButton;

    @FXML
    private TextField num1;

    @FXML
    private TextField num2;

    @FXML
    private TextField answer;

    @FXML
    void addition(ActionEvent event) {
    	int result = Integer.parseInt(num1.getText()) + Integer.parseInt(num2.getText());
    	answer.setText(String.valueOf(result));

    }

}

